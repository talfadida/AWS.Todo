﻿using Aws.Todo.Model;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;

namespace AWS.Todo.Api
{ 
    /// <summary>
    /// use this class in singleton scope
    /// </summary>
    public class InMemoryRepository : IRepository
    {

        ///allow multi threading with minimal locks
        ConcurrentDictionary<string, ITodoItem> repo = new ConcurrentDictionary<string, ITodoItem>();
        private readonly ILogger<IRepository> _logger;

        public InMemoryRepository(ILogger<IRepository> logger)
        {
            this._logger = logger;
        }

        public void TrySave(ITodoItem todoItem)
        {
            try
            {

                if (todoItem == null)
                    throw new TodoException("todoItem is null");

                if (string.IsNullOrEmpty(todoItem.Title))
                    throw new TodoException("Item must have title");

                if (!repo.TryAdd(todoItem.Title, todoItem))
                    throw new TodoException($"item {todoItem.Title} already exist");

                _logger.LogInformation($"item {todoItem.Title} was added");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error happened: " + ex.Message);
                throw ex;
            }
        }


        public void TryRemove(string title)
        {
            try
            {

                if (string.IsNullOrEmpty(title))
                    throw new TodoException("title is missing");

                if (!repo.TryRemove(title, out var itemRemoved))
                    throw new TodoException($"item {title} is not exist");

                _logger.LogInformation($"item {title} was removed");

                
            }
            catch (Exception ex)
            {
                _logger.LogError("Error happened: " + ex.Message);
                throw ex;
            }
        }

        public IEnumerable<ITodoItem> GetItems(bool onlyCompleted = false)
        {
            _logger.LogInformation("GetItems Request was issued");

            if (onlyCompleted)
                return repo.Values.Where(p => p.IsCompleted);

            return repo.Values;
        }

        public void UpdateTask(string originalTitle, string newTitle)
        {
            try
            {
                if (string.IsNullOrEmpty(originalTitle))
                    throw new TodoException("originalTitle is missing");
                if (string.IsNullOrEmpty(newTitle))
                    throw new TodoException("newTitle is missing");
                if (repo.ContainsKey(newTitle))
                    throw new TodoException($"update failed. task {newTitle} already exist");

                if (!repo.TryGetValue(originalTitle, out var currrentTask))
                    throw new TodoException($"task {originalTitle} is not exist");


                lock (repo) //Let's guard the remove and add to be thread-safe (atomic)
                {
                    currrentTask.Title = newTitle;
                    repo.TryRemove(originalTitle, out var _);
                    repo.TryAdd(newTitle, currrentTask);
                }

                _logger.LogInformation($"Update task done successfully: {originalTitle} -> {newTitle}");

            }
            catch (Exception ex)
            {
                _logger.LogError("Error happened: " + ex.Message);
                throw ex;
            }
        }

        public void SetCompletedMode(string title, bool isCompleted)
        {
            try
            {
                if (string.IsNullOrEmpty(title))
                    throw new TodoException("newTitle is missing");
                if (!repo.TryGetValue(title, out var currrentTask))
                    throw new TodoException($"task {title} is not exist");
                currrentTask.IsCompleted = isCompleted;
                _logger.LogInformation($"SetCompletedMode task done successfully: {title}.IsCompleted -> {isCompleted}");
            }
            catch (Exception ex)
            {
                _logger.LogError("Error happened: " + ex.Message);
                throw ex;
            }
        }



    }
}
