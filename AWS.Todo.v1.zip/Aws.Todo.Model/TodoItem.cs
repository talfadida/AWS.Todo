﻿using System;

namespace Aws.Todo.Model
{


    [Serializable]
    public class TodoItem : ITodoItem
    {
        public string Title { get; set; }               
        public bool IsCompleted { get; set; }
        public string NewTitle { get; set; }

        //public DateTime WhenCompleted { get; set; }
        //public DateTime WhenStarted { get; set; }



    }
}
