using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using Aws.Todo.Model;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace AWS.Todo.Process
{
    public class TodoServer
    {
        private readonly IRepository _repo;

        //public TodoServer(IRepository repo)
        //{
        //    this._repo = repo;
        //}

        public TodoServer()
        {
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);
            var serviceProvider = serviceCollection.BuildServiceProvider();           
            this._repo = serviceProvider.GetService<IRepository>();
            
        }

        private void ConfigureServices(IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IRepository, Repository>();
        }

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public string TodoQueueHandler(TodoItem sqsEvent, ILambdaContext context)
        {

            StringBuilder sb = new StringBuilder();

            try
            {

                _repo.Save(sqsEvent);
                sb.AppendLine($"Task Saved: {sqsEvent.Title}");


                //sb.AppendLine($"Beginning to process {sqsEvent.Records.Count} tasks...");

                //foreach (var record in sqsEvent.Records)
                //{
                //    TodoItem todoItem = JsonConvert.DeserializeObject<TodoItem>(record.Body);
                //    _repo.Save(todoItem);
                //    sb.AppendLine($"Task Saved: {todoItem.Title}");
                //}

                sb.AppendLine("Processing complete.");
                LambdaLogger.Log(sb.ToString());
                return $"done";
            }
            catch (Exception ex)
            {
                sb.AppendLine(ex.ToString());
                LambdaLogger.Log(sb.ToString());
                throw ex;
            }
        }
    }
}
