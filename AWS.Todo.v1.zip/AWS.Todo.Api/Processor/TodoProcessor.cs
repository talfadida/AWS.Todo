﻿using Aws.Todo.Model;
using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace AWS.Todo.Api
{

    public class TodoProcessor : ITodoProcessor
    {
        private readonly IRepository _repo;
        
        public TodoProcessor(IRepository repo)
        {
            this._repo = repo;           
        }



        public async Task<TodoResponse> Handle(TodoCommand command)
        {
            try
            {
                return await Task.Run(() =>
                {
                    switch (command.Operation)
                    {
                        case EnumOperation.Add:
                            _repo.TrySave(command.TodoItem);
                            return command.CreateSuccessResponse(null);
                        case EnumOperation.Update:
                            _repo.UpdateTask(command.TodoItem.Title, command.TodoItem.NewTitle);
                            return command.CreateSuccessResponse(null);
                        case EnumOperation.Delete:
                            _repo.TryRemove(command.TodoItem.Title);
                            return command.CreateSuccessResponse(null);
                        case EnumOperation.Complete:
                            _repo.SetCompletedMode(command.TodoItem.Title, true);
                            return command.CreateSuccessResponse(null);
                        case EnumOperation.Undo:
                            _repo.SetCompletedMode(command.TodoItem.Title, false);
                            return command.CreateSuccessResponse(null);
                        case EnumOperation.List:
                            var list = _repo.GetItems();
                            return command.CreateSuccessResponse(list);
                        case EnumOperation.ListCompleted:
                            var listCompleted = _repo.GetItems(true);
                            return command.CreateSuccessResponse(listCompleted);
                        default:
                            throw new Exception($"Unhandled operation {command.Operation}");
                    }
                });
            }
            catch(Exception ex)
            {
                return command.CreateFailureResponse(ex.Message);
            }
        }
    }
}
