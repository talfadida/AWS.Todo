﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Aws.Todo.Model
{

    [Serializable]
    public class TodoCommand: TodoOperation
    {       
        public TodoItem TodoItem { get; set; }

        public TodoResponse CreateSuccessResponse(object data)
        {
            return new TodoResponse()
            {
                IsSuccess = true,
                Operation = this.Operation,
                Data = data
            };
        }

        public TodoResponse CreateFailureResponse(string error)
        {
            return new TodoResponse()
            {
                IsSuccess = false,
                Operation = this.Operation,
                Data = error
            };
        }
    }


}
