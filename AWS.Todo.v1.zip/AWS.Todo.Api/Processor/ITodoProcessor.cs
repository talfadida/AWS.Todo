﻿using Aws.Todo.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AWS.Todo.Api
{
    public interface ITodoProcessor
    {
        Task<TodoResponse> Handle(TodoCommand command);
    }
}
