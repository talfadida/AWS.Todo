using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Lambda.Core;
using Amazon.SQS;
using Amazon.SQS.Model;
using Aws.Todo.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AWS.Todo.Api.Controllers
{
    [ApiController]
    public class TodoController : ControllerBase
    {
       
        private readonly ILogger<TodoController> _logger;
        private readonly ITodoProcessor _processor;

        //private readonly IAmazonSQS _sqsClient;

        public TodoController(ILogger<TodoController> logger, ITodoProcessor processor /*IAmazonSQS sqsClient*/)
        {
            //this._sqsClient = sqsClient;

            
            this._logger = logger;
            this._processor = processor;
        }
 
        // POST api/values
        [Route("api/operation")]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] TodoCommand command)
        {
            try
            { 
                //string jsonMsgBody = JsonConvert.SerializeObject(value);
                //var req = new SendMessageRequest("https://sqs.us-east-2.amazonaws.com/323237361150/dataq", jsonMsgBody);
                //await _sqsClient.SendMessageAsync(req);
                //LambdaLogger.Log("Message sent successfully"); 


                var processorResponse = await _processor.Handle(command);

                if (processorResponse.IsSuccess)
                    return Ok(processorResponse);
                else
                    return StatusCode(500, processorResponse);
            }
            catch(Exception ex)
            {
                //LambdaLogger.Log("Error happened: " + ex);

                return StatusCode(500, command.CreateFailureResponse(ex.Message));
            }

        }

       
    }
}
