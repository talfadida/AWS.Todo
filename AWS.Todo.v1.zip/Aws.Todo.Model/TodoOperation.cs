﻿using System;

namespace Aws.Todo.Model
{
    public abstract class TodoOperation
    {
        public Guid OperationUUID { get; set; }
        public EnumOperation Operation { get; set; }
    }


}
