﻿using Aws.Todo.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace todo
{
    class Program
    {
        static async Task Main(string[] args)
        {
            List<string[]> inputs = new List<string[]>()
            {
                new[]{"add-task", "task1"},
                new[]{"add-task", "task2"},
                new[]{"add-task", "task2"},
                new[]{"update-task", "task1", "task3"},
                new[]{"list-task"},
                new[]{"complete-task", "task2"},
                new[]{"list-task"},
            };

            foreach (var input in inputs)
            {
                Arguments arguments = Arguments.ParseArgs(input);
                if (arguments == null)
                {
                    Arguments.PrintHelp();
                    return;
                }

                await ExecuteTodoOperation(arguments);
            }

        }

        private static async Task ExecuteTodoOperation(Arguments arguments)
        {
            string server_url = "http://localhost:65359/api/operation";
            using (HttpClient httpClient = new HttpClient())
            {
                TodoCommand cmd = new TodoCommand()
                {                   
                    Operation = arguments.Operation,
                    TodoItem = new TodoItem()
                    {
                        Title = arguments.Title,
                        NewTitle = arguments.NewTitle,
                        IsCompleted = arguments.IsCompleted
                    }
                };
                Console.WriteLine("Sending operation " + cmd.OperationUUID);
                HttpContent content = new StringContent(JsonConvert.SerializeObject(cmd), Encoding.UTF8, "application/json");
                var response = await httpClient.PostAsync(server_url, content);              
                var bodyOfResponse = await response.Content.ReadAsStringAsync();
                Console.WriteLine(bodyOfResponse);
            }
        }
    }
}
