﻿using Aws.Todo.Model;
using System.Collections.Generic;

namespace AWS.Todo.Api
{
    public interface IRepository
    {

        

        IEnumerable<ITodoItem> GetItems(bool onlyCompleted = false);
        
        void SetCompletedMode(string title, bool isCompleted);
        
        void TryRemove(string title);
        
        void TrySave(ITodoItem todoItem);
        
        void UpdateTask(string originalTitle, string newTitle);
        
    }
}