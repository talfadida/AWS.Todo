﻿using System;

namespace Aws.Todo.Model
{
    [Serializable]
    public class TodoResponse: TodoOperation
    {
       
        public bool IsSuccess { get; set; }

        public object  Data { get; set; } 
    }


}
