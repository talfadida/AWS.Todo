﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: FunctionsStartup(typeof(AWS.Todo.Process.Startup))]

namespace AWS.Todo.Process
{
    public class Startup : FunctionsStartup
    {
        private IConfigurationBuilder _config;

        public override void ConfigureAppConfiguration(IFunctionsConfigurationBuilder builder)
        {
            _config = builder.ConfigurationBuilder;            
            _config.AddEnvironmentVariables();
        }


        public override void Configure(IFunctionsHostBuilder builder)
        {
            //builder.Services.AddDefaultAWSOptions(Configuration.GetAWSOptions());
            //builder.Services.AddAWSService<IAmazonSQS>();
            builder.Services.AddSingleton<IRepository, Repository>();
        }

    }
}
