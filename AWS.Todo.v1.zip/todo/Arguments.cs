﻿using System;
using System.Collections.Generic;
using System.Text;
using Aws.Todo.Model;
using CommandLine;

namespace todo
{
    public class Arguments
    {
        public EnumOperation Operation { get; internal set; }
        public string Title { get; internal set; }
        public string NewTitle { get; internal set; }
        public bool IsCompleted { get; internal set; }
        


        internal static Arguments ParseArgs(string[] args)
        {
            try
            {
                if (args.Length == 0)
                    return null;

                switch (args[0])
                {
                    case "add-task":
                        return new Arguments() { Operation = EnumOperation.Add, Title = args[1] };
                    case "update-task":
                        return new Arguments() { Operation = EnumOperation.Update, Title = args[1], NewTitle = args[2] };
                    case "complete-task":
                        return new Arguments() { Operation = EnumOperation.Complete, IsCompleted = true, Title = args[1] };
                    case "undo-task":
                        return new Arguments() { Operation = EnumOperation.Undo, IsCompleted = false, Title = args[1] };
                    case "delete-task":
                        return new Arguments() { Operation = EnumOperation.Delete, Title = args[1] };
                    case "list-task":
                        return new Arguments() { Operation = EnumOperation.List };
                    case "list-completed-task":
                        return new Arguments() { Operation = EnumOperation.ListCompleted };
                }
            }
            catch 
            {
               //wrong usage
            }
            return null;
        }

        internal static void PrintHelp()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Usage:");
            sb.AppendLine(@"todo add-task ""TASK NAME""");
            sb.AppendLine(@"todo update-task ""TASK NAME"" ""NEW TASK NAME"" ");
            sb.AppendLine(@"todo complete-task ""TASK NAME""");
            sb.AppendLine(@"todo undo-task ""TASK NAME""");
            sb.AppendLine(@"todo delete-task ""TASK NAME""");
            sb.AppendLine(@"todo list-tasks");
            sb.AppendLine(@"todo list-completed-tasks");
            Console.WriteLine(sb.ToString());
        }
    }
}
