﻿using Aws.Todo.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace AWS.Todo.Process
{
    public interface IRepository
    {
        void Save(TodoItem todoItem);
    }
    public class Repository : IRepository
    {
        public void Save(TodoItem todoItem)
        {
             
        }
    }
}
