﻿using System;

namespace Aws.Todo.Model
{
    public interface ITodoItem
    {
       
        string Title { get; set; }
        bool IsCompleted { get; set; }
        //DateTime WhenCompleted { get; set; }
        //DateTime WhenStarted { get; set; }
    }
}